export const ACTOR = "RuyiNativeTelemetry";
export const ROOT = "resource://gre/modules/ruyi-native/";
export const LIMIT = 4096;
export const HARNESS = "/harness";
const fields = {jscall: ["scriptPath", "functionName", "jsStartLine", "jsStartColumn"],
  wasm: ["scriptPath", "functionName", "wasmFunctionIndex", "wasmModuleHash", "wasmEntryOffset", "wasmCompileLine"],
  http: ["httpPath"], websocket: ["websocketPath"]};
const common = ["schema", "runId", "origin", "enabled", "profile", "mode"];
const uint = (n, max = 0xffffffff) => Number.isSafeInteger(n) && n >= 0 && n <= max;
const match = (s, re, max) => typeof s === "string" && s.length <= max && re.test(s);

export function validatedConfig(c) {
  if (!c || Object.getPrototypeOf(c) !== Object.prototype || c.schema !== 1 ||
      typeof c.enabled !== "boolean" || !Object.hasOwn(fields, c.mode) ||
      !match(c.runId, /^[0-9a-f]{32}$/, 32) ||
      !match(c.origin, /^http:\/\/127\.0\.0\.1:[1-9][0-9]{0,4}$/, 22) ||
      !match(c.profile, /^\//, 512) ||
      Object.keys(c).some(k => !common.includes(k) && !fields[c.mode].includes(k))) {
    return null;
  }
  const port = Number(c.origin.split(":").pop());
  if (port < 1024 || port > 65535) {
    return null;
  }
  if ((c.mode === "jscall" || c.mode === "wasm") && (
    !match(c.scriptPath, /^\/[A-Za-z0-9._-]+(?:\/[A-Za-z0-9._-]+)*$/, 96) ||
    c.scriptPath.split("/").some(x => x === "." || x === "..") ||
    !(c.mode === "jscall" ? c.functionName === "fixedAdd" : ["add", "trap"].includes(c.functionName)))) {
    return null;
  }
  if (c.mode === "jscall" && (!uint(c.jsStartLine, 65535) || !c.jsStartLine || !uint(c.jsStartColumn, 65535) || !c.jsStartColumn)) {
    return null;
  }
  if (c.mode === "wasm" && (c.wasmFunctionIndex !== 0 ||
      !match(c.wasmModuleHash, /^[0-9a-f]{16}$/, 16) || !uint(c.wasmEntryOffset, 0x100000) || c.wasmEntryOffset < 8 ||
      !uint(c.wasmCompileLine, 65535) || !c.wasmCompileLine)) {
    return null;
  }
  if (c.mode === "http" && !["/qa-http", "/qa-redirect", "/qa-cache"].includes(c.httpPath)) {
    return null;
  }
  if (c.mode === "websocket" && c.websocketPath !== "/qa-ws") {
    return null;
  }
  return Object.freeze({...c});
}

export function allowedDocument(context, principal, uri, origin) {
  const attrs = principal?.originAttributes;
  return context && context.top === context && Boolean(principal?.isContentPrincipal) &&
    principal.originNoSuffix === origin && (attrs?.privateBrowsingId ?? 0) === 0 &&
    (attrs?.userContextId ?? 0) === 0 && uri?.scheme === "http" &&
    uri.prePath === origin && uri.spec === origin + HARNESS;
}

export function validatedRow(c, r) {
  if (!r || Object.getPrototypeOf(r) !== Object.prototype || r.family !== c.mode ||
      Object.keys(r).length > 7) {
    return null;
  }
  const {family, kind} = r;
  let bounded;
  if (family === "jscall" || family === "wasm") {
    if (!["enter", "return", "throw"].includes(kind) || !uint(r.call, LIMIT) || !r.call ||
        r.functionKind !== (family === "jscall" ? "js" : "wasm")) {
      return null;
    }
    bounded = {family, kind, call: r.call, functionKind: r.functionKind};
    if (family === "wasm") {
      if (r.functionIndex !== c.wasmFunctionIndex || !uint(r.moduleId) || !r.moduleId) {
        return null;
      }
      Object.assign(bounded, {functionIndex: r.functionIndex, moduleId: r.moduleId});
    }
  } else if (family === "http") {
    if (kind !== "transaction" || !uint(r.chain) || !r.chain ||
        r.method !== "GET" || !["network", "cache"].includes(r.transport) ||
        !uint(r.status, 599) || r.status < 100) {
      return null;
    }
    bounded = {family, kind, chain: r.chain, transport: r.transport, method: r.method, status: r.status};
  } else if (family === "websocket") {
    if (kind !== "frame" || !uint(r.connection) || !r.connection ||
        !["rx", "tx"].includes(r.direction) || ![0, 1, 2, 8, 9, 10].includes(r.opcode) ||
        typeof r.fin !== "boolean" || !uint(r.length, 0x100000)) {
      return null;
    }
    bounded = {family, kind, connection: r.connection, direction: r.direction,
      opcode: r.opcode, fin: r.fin, length: r.length};
  }
  return bounded && Object.keys(r).length === Object.keys(bounded).length &&
    Object.keys(r).every(k => Object.hasOwn(bounded, k)) ? bounded : null;
}
