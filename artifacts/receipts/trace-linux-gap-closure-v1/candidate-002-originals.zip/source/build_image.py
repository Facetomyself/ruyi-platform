#!/usr/bin/env python3
"""Append a deterministic local image layer to one precisely locked CLI image.

No pull, Dockerfile builder, tags, daemon changes, or repositories are used. The
builder consumes the native daemon's CLI image archive by immutable config ID.
"""
import argparse
import configparser
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import struct
import subprocess
import tarfile
import tempfile
import zipfile

HERE = Path(__file__).resolve().parent
LOCK = {
    "sha256:9073c375ff26a8248e055e54f1ca28f289d92fc7f253d36685973fa8ecdd33bc": (
        "arm64", "20261125162841", {
            "firefox": "85c7a26b03d1d7466260c9bbfd1600ac3000aab39b1e946af0576f5186bb6f40",
            "libxul.so": "a1b20f09c609511511485609502f36ac400637bc6884c9bd3c89bed29e7f3c19",
            "omni.ja": "d4f278be6f9e3c380ffcb00bf2711029484b2cbc98a2126429e727c795235ae4",
            "browser/omni.ja": "08f6472e8ed4b2764a59848d91ef62707f1a68063707ff276894c6061116aef6",
        }),
    "sha256:eb73d165ea9adc15864aeb054bc90a78670618c5c0606827997d357f1cae05c6": (
        "amd64", "20261123161729", {
            "firefox": "49642c7be1ffa190e6b6f545b3394b44d01b04659836bc00eec2fdc23f661312",
            "libxul.so": "ac25767f89d2fa0099e665a630d2a499ad3e94f3ecac12ad71929476046e40ad",
            "omni.ja": "1167a101f5e50332a767a3dcdcec4f7acbb7242c25d3613a760fd0f3caab61c7",
            "browser/omni.ja": "2ea827771138189128c0f9f0b5d9bc2100c9a112ac3601b7c5f14edb99ba93e5",
        }),
}
ACTOR_MANAGER = "modules/ActorManagerParent.sys.mjs"
OMNI_DIR = "modules/ruyi-native/"
HOOK = b'''\n// RuyiTrace local opt-in only; packaged in this normal Gecko parent startup module.\nif (Services.env.get("MOZ_RUYITRACE_NATIVE_DIR")) {\n  try {\n    ChromeUtils.importESModule("resource://gre/modules/ruyi-native/Start.sys.mjs").boot();\n  } catch (error) {\n    Cu.reportError(error);\n  }\n}\n'''
ANCHOR = b"ActorManagerParent.addJSWindowActors(JSWINDOWACTORS);"
RUNTIME = ("Policy.sys.mjs", "Writer.sys.mjs", "Start.sys.mjs", "RuyiNativeTelemetryParent.sys.mjs",
           "RuyiNativeTelemetryChild.sys.mjs")
PRODUCERS = ("compute/Compute.sys.mjs", "net/Network.sys.mjs")
SOURCE = (*RUNTIME, "build_image.py", "launch.py", "config.py")
DOCKER = ("docker",)


def encode(value):
    return (json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True) + "\n").encode()


def sha(value):
    return hashlib.sha256(value).hexdigest()


def hash_file(p):
    h = hashlib.sha256()
    with p.open("rb") as f:
        for data in iter(lambda: f.read(1024**2), b""):
            h.update(data)
    return h.hexdigest()


def check(condition, reason):
    if not condition:
        raise ValueError(reason)


def docker(*args, **kw):
    if kw.pop("capture_output", False):
        kw.update(stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if kw.pop("text", False):
        kw["universal_newlines"] = True
    return subprocess.run((*DOCKER, *args), check=True, **kw)


def get_base_file(base, src, dst):
    with dst.open("xb") as f:
        docker("run", "--rm", "--pull", "never", "--read-only", "--network", "none",
               "--cap-drop", "ALL", "--security-opt", "no-new-privileges", "--entrypoint", "/bin/cat",
               base, f"/browser/{src}", stdout=f)


def read_version(root):
    config = configparser.ConfigParser(interpolation=None)
    config.read(root / "application.ini", encoding="utf-8")
    check(config["App"]["Version"] == "159.0", "unexpected Firefox version")
    build = config["App"]["BuildID"]
    check(re.fullmatch(r"[0-9]{14}", build), "unexpected Firefox BuildID")
    return build


def extract_patch(archive, dest, arch):
    # Constrain paths and archive members; the authorized archive digest comes from the operator.
    with tarfile.open(archive, "r:*") as tar:
        members = tar.getmembers()
        entries = {}
        for m in members:
            p = PurePosixPath(m.name)
            check(not p.is_absolute() and ".." not in p.parts and not (p.parts and "\\" in m.name), "unsafe package path")
            if not p.parts:
                check(m.isdir(), "unsafe package root")
                continue
            check(m.isfile() or m.isdir(), "patched Firefox package uses an unsupported archive member")
            check(p not in entries, "duplicate patched Firefox package member")
            entries[p] = m
        matches = [p.parent for p in entries if p.name == "application.ini"]
        check(len(matches) == 1, "patched package must have exactly one Firefox root")
        for p, m in sorted(entries.items()):
            if m.isdir():
                continue
            try:
                relative = p.relative_to(matches[0])
            except ValueError:
                raise ValueError("unexpected file outside Firefox root")
            out = dest / relative
            out.parent.mkdir(parents=True, exist_ok=True)
            with tar.extractfile(m) as source, out.open("xb") as target:
                shutil.copyfileobj(source, target, 1024**2)
            out.chmod(0o555 if m.mode & 0o111 else 0o444)
    for name in ("firefox", "libxul.so"):
        with (dest / name).open("rb") as f:
            header = f.read(20)
        check(header[:6] == b"\x7fELF\x02\x01" and
              struct.unpack_from("<H", header, 18)[0] == {"arm64": 183, "amd64": 62}[arch],
              "patched package ELF architecture mismatch")


def patch_omni(original, modified, modules):
    with zipfile.ZipFile(original) as src, zipfile.ZipFile(modified, "x", allowZip64=False) as dst:
        names = src.namelist()
        check(len(names) == len(set(names)) and not any(x.startswith(OMNI_DIR) for x in names), "omni namespace already used")
        check(ACTOR_MANAGER in names, "normal startup ActorManagerParent is missing")
        hashes = {}
        for info in src.infolist():
            data = src.read(info)
            if info.filename == ACTOR_MANAGER:
                check(data.count(ANCHOR) == 1 and data.rstrip().endswith(ANCHOR), "unexpected ActorManagerParent integration anchor")
                hashes["old_actor_sha256"] = sha(data)
                data += HOOK
                hashes["actor_sha256"] = sha(data)
            # Use deterministic timestamps/compression without generating stale optimized offsets.
            entry(dst, info.filename, data, info.compress_type, info.external_attr)
        for name, data in sorted(modules.items()):
            entry(dst, OMNI_DIR + name, data, zipfile.ZIP_DEFLATED, (stat.S_IFREG | 0o444) << 16)
    return hashes


def entry(dst, name, data, compression, attributes):
    info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
    info.compress_type = compression
    info.external_attr = attributes
    info.create_system = 3
    dst.writestr(info, data)


def tar_file(dst, name, path_or_data, mode=0o444):
    t = tarfile.TarInfo(name)
    t.mode = mode
    if isinstance(path_or_data, Path):
        t.size = path_or_data.stat().st_size
        with path_or_data.open("rb") as f:
            dst.addfile(t, f)
    else:
        t.size = len(path_or_data)
        dst.addfile(t, io.BytesIO(path_or_data))


def append_image(base, archive, diff, build_info):
    with tarfile.open(archive) as old:
        rows = json.load(old.extractfile("manifest.json"))
        check(len(rows) == 1, "need exactly one base platform/config in Docker archive")
        row = rows[0]
        config_data = old.extractfile(row["Config"]).read()
        check("sha256:" + sha(config_data) == base, "Docker archive config is not the requested exact ID")
        c = json.loads(config_data)
        check(c["architecture"] == build_info["architecture"] and c["os"] == "linux" and
              c["config"]["User"] == "1000:1000" and c["rootfs"]["type"] == "layers" and
              len(c["rootfs"]["diff_ids"]) == len(row["Layers"]), "unexpected archive base metadata")
        check(all("sha256:" + sha_hint(old, n) == digest for n, digest in zip(row["Layers"], c["rootfs"]["diff_ids"])),
              "base archive layer does not match its config diff ID")
        diff_id = hash_file(diff)
        c["rootfs"]["diff_ids"].append("sha256:" + diff_id)
        c.setdefault("history", []).append({"created": "1970-01-01T00:00:00Z", "created_by": "RuyiTrace Firefox159 native-events overlay v1"})
        c["config"]["Entrypoint"] = ["/opt/ruyitrace/tini", "--", "/usr/local/bin/ruyitrace-native"]
        c["config"]["Cmd"] = ["--help"]
        c["config"].setdefault("Labels", {}).update({
            "org.opencontainers.image.title": "RuyiTrace Firefox 159 local native telemetry candidate",
            "io.ruyitrace.product.scope": build_info["scope"],
            "io.ruyitrace.native.base": base,
            "io.ruyitrace.native.package.sha256": sha(encode(build_info)),
        })
        data = encode(c)
        ident = sha(data)
        new_config = f"blobs/sha256/{ident}"
        new_layer = f"blobs/sha256/{diff_id}"
        manifest = {"Config": new_config, "RepoTags": [], "Layers": [*row["Layers"], new_layer]}
        proc = subprocess.Popen((*DOCKER, "image", "load", "--quiet"), stdin=subprocess.PIPE)
        try:
            with tarfile.open(fileobj=proc.stdin, mode="w|") as dst:
                tar_file(dst, "manifest.json", encode([manifest]))
                tar_file(dst, new_config, data)
                for name in dict.fromkeys(row["Layers"]):
                    m = old.getmember(name)
                    check(m.isfile(), "base image layer is not regular")
                    dst.addfile(m, old.extractfile(m))
                tar_file(dst, new_layer, diff)
        finally:
            proc.stdin.close()
            rc = proc.wait()
        check(rc == 0, f"Docker archive load exited {rc}")
        return "sha256:" + ident, "sha256:" + diff_id


def sha_hint(tar, name):
    raw = tar.extractfile(name)
    h = hashlib.sha256()
    with raw:
        magic = raw.read(4)
        raw.seek(0)
        if magic[:2] == b"\x1f\x8b":
            with gzip.GzipFile(fileobj=raw) as source:
                for data in iter(lambda: source.read(1024**2), b""):
                    h.update(data)
        else:
            check(magic != bytes.fromhex("28b52ffd"), "zstd image save blobs are unsupported")
            for data in iter(lambda: raw.read(1024**2), b""):
                h.update(data)
    return h.hexdigest()


def assemble(args):
    arch, build_id, old_hashes = LOCK[args.base]
    actual = docker("info", "--format", "{{.Architecture}}", capture_output=True, text=True).stdout.strip()
    check({"aarch64": "arm64", "x86_64": "amd64"}.get(actual, actual) == arch, "requires the exact architecture's native daemon")
    modules = {f: (HERE / f).read_bytes() for f in RUNTIME}
    sources = {f: hash_file(HERE / f) for f in SOURCE}
    producer_root = HERE.parent
    if not args.startup_proof:
        for f in PRODUCERS:
            modules[f] = (producer_root / f).read_bytes()
            sources[f] = sha(modules[f])
    check(bool(args.patched_firefox) == bool(args.patched_sha256), "both independently locked patched archive arguments are required")
    options = args.out.absolute()
    options.mkdir(mode=0o700)
    with tempfile.TemporaryDirectory(prefix="assembly-", dir=options) as tmp:
        temp = Path(tmp)
        base_files = temp / "base-browser"
        base_files.mkdir()
        for name in ("application.ini", *old_hashes):
            target = base_files / name
            target.parent.mkdir(exist_ok=True, parents=True)
            get_base_file(args.base, name, target)
        check(read_version(base_files) == build_id, "locked browser base BuildID mismatch")
        check(all(hash_file(base_files / name) == digest for name, digest in old_hashes.items()), "locked base browser file mismatch")
        patch_hash = None
        firefox = base_files
        if args.patched_firefox:
            patch_hash = hash_file(args.patched_firefox)
            check(re.fullmatch(r"[0-9a-f]{64}", args.patched_sha256) and patch_hash == args.patched_sha256, "patched package archive digest mismatch")
            firefox = temp / "patched-browser"
            firefox.mkdir()
            extract_patch(args.patched_firefox, firefox, arch)
        new_omni = temp / "omni.ja"
        actor_hashes = patch_omni(firefox / "omni.ja", new_omni, modules)
        new_hashes = {name: hash_file(new_omni if name == "omni.ja" else firefox / name) for name in old_hashes}
        package = {"schema": 1, "scope": "native-events-startup-proof" if args.startup_proof else "native-events-candidate",
                   "architecture": arch, "base_image_id": args.base, "firefox_root": "/browser", "firefox_version": "159.0",
                   "old_build_id": build_id, "build_id": read_version(firefox), "old_package_sha256": old_hashes,
                   "package_sha256": new_hashes, "patched_firefox_archive_sha256": patch_hash,
                   "pre_overlay_omni_sha256": hash_file(firefox / "omni.ja"), **actor_hashes,
                   "source_sha256": sources, "source_set_sha256": sha(encode(sources)),
                   "archive_modules": {OMNI_DIR + k: sha(v) for k, v in sorted(modules.items())}}
        layer = temp / "layer.tar"
        with tarfile.open(layer, "w", format=tarfile.PAX_FORMAT) as t:
            if args.patched_firefox:
                # The old package is hidden behind an opaque overlay directory; no mixed Gecko package.
                tar_file(t, "browser/.wh..wh..opq", b"")
                for p in sorted(firefox.rglob("*")):
                    if p.is_file() and p != firefox / "omni.ja":
                        tar_file(t, f"browser/{p.relative_to(firefox).as_posix()}", p, stat.S_IMODE(p.stat().st_mode))
            tar_file(t, "browser/omni.ja", new_omni)
            tar_file(t, "usr/local/bin/ruyitrace-native", HERE / "launch.py", 0o555)
            tar_file(t, "opt/ruyitrace-native/config.py", HERE / "config.py")
            tar_file(t, "opt/ruyitrace-native/package.json", encode(package))
        archive = temp / "base-image.tar"
        docker("image", "save", "--output", str(archive), args.base)
        image_id, diff_id = append_image(args.base, archive, layer, package)
        inspected = json.loads(docker("image", "inspect", image_id, capture_output=True).stdout)[0]
        check(inspected["Id"] == image_id and inspected["Architecture"] == arch and inspected["RootFS"]["Layers"][-1] == diff_id,
              "installed candidate image metadata mismatch")
        check(not inspected.get("RepoTags"), "candidate must remain untagged and run only by ID")
        installed = docker("run", "--rm", "--pull", "never", "--read-only", "--network", "none", "--cap-drop", "ALL",
                           "--security-opt", "no-new-privileges", image_id, "verify", capture_output=True).stdout
        check(installed == encode(package), "installed package manifest mismatch")
    report = {**package, "candidate_image_id": image_id, "overlay_diff_id": diff_id, "manifest_sha256": sha(encode(package))}
    (options / "image.json").write_bytes(encode(report))
    print(image_id)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--base", required=True, choices=LOCK)
    p.add_argument("--out", required=True, type=Path, help="new output directory")
    p.add_argument("--patched-firefox", type=Path)
    p.add_argument("--patched-sha256")
    p.add_argument("--startup-proof", action="store_true", help="isolated integration probe only; omit both producers, not a candidate")
    args = p.parse_args()
    try:
        assemble(args)
    except (OSError, ValueError, KeyError, subprocess.CalledProcessError, tarfile.TarError, zipfile.BadZipFile) as e:
        p.exit(1, f"build_image: {e}\n")


if __name__ == "__main__":
    main()
