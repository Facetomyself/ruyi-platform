#!/usr/bin/python3 -I
"""Installed by the image builder. Launch only the same bundled Firefox."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import zipfile

sys.path.insert(0, "/opt/ruyitrace-native")
from config import load_config, private_dir


def verify():
    raw = Path("/opt/ruyitrace-native/package.json").read_bytes()
    package = json.loads(raw)
    for name, want in package["package_sha256"].items():
        with (Path("/browser") / name).open("rb") as f:
            digest = hashlib.file_digest(f, "sha256").hexdigest()
        if digest != want:
            raise ValueError("installed browser package digest mismatch")
    with zipfile.ZipFile("/browser/omni.ja") as z:
        for name, want in {**package["archive_modules"],
                           "modules/ActorManagerParent.sys.mjs": package["actor_sha256"]}.items():
            if hashlib.sha256(z.read(name)).hexdigest() != want:
                raise ValueError("installed browser module digest mismatch")
    sys.stdout.buffer.write(raw)


def main():
    p = argparse.ArgumentParser(prog="ruyitrace-native")
    commands = p.add_subparsers(dest="command", required=True)
    run = commands.add_parser("run")
    run.add_argument("--dir", required=True)
    run.add_argument("--url", required=True)
    commands.add_parser("verify")
    if len(sys.argv) == 1:
        p.print_help()
        return 0
    a = p.parse_args()
    try:
        if a.command == "verify":
            verify()
            return 0
        if os.geteuid() == 0:
            raise ValueError("run with the image's unprivileged browser user")
        os.umask(0o077)
        c = load_config(a.dir, a.url)
        # Only pass data already checked against real uid, inode type, permissions, and scope.
        # Do not forward profile overrides, injection, proxies, or a network/debugger control surface.
        env = {"PATH": "/usr/local/bin:/usr/bin:/bin", "LANG": "C.UTF-8", "TZ": "UTC"}
        for key, leaf in (("HOME", "home"), ("XDG_RUNTIME_DIR", "xdg")):
            directory = Path(a.dir) / leaf
            directory.mkdir(mode=0o700)
            env[key] = str(private_dir(directory))
        env["MOZ_RUYITRACE_NATIVE_DIR"] = a.dir
        env["MOZ_RUYITRACE_NATIVE_CONFIG"] = json.dumps(c, separators=(",", ":"))
        firefox = "/browser/firefox"
        os.execve(firefox, [firefox, "-headless", "-no-remote", "-profile", c["profile"], a.url], env)
    except (OSError, ValueError) as e:
        print(f"ruyitrace-native: {e}", file=sys.stderr)
        return 3


if __name__ == "__main__":
    sys.exit(main())
