import {LIMIT, ROOT, allowedDocument, validatedConfig, validatedRow} from "resource://gre/modules/ruyi-native/Policy.sys.mjs";

export class RuyiNativeTelemetryChild extends JSWindowActorChild {
  armed = false;
  sent = 0;
  invalid = 0;
  limit = 0;

  scoped() {
    const doc = this.document;
    return this.cfg && doc && allowedDocument(this.browsingContext, doc.nodePrincipal, doc.documentURIObject, this.cfg.origin);
  }

  ready(data) {
    this.cfg = validatedConfig(data);
    return Boolean(this.scoped() && this.document.readyState !== "loading");
  }

  emit(row) {
    if (!this.armed || !this.scoped()) {
      return;
    }
    const data = validatedRow(this.cfg, row);
    if (!data) {
      this.invalid = Math.min(0xffffffff, this.invalid + 1);
      return;
    }
    if (this.sent >= LIMIT) {
      this.limit = Math.min(0xffffffff, this.limit + 1);
      return;
    }
    this.sendAsyncMessage("Row", data);
    this.sent++;
  }

  async receiveMessage({name, data}) {
    if (name === "Ready" && !this.started) {
      return {ready: this.ready(data)};
    }
    if (data !== null || !this.scoped()) {
      throw new Error("native telemetry child rejected control");
    }
    if (name === "Start" && !this.started) {
      this.started = true;
      if (this.cfg.enabled && ["jscall", "wasm"].includes(this.cfg.mode)) {
        const {attachCompute} = ChromeUtils.importESModule(ROOT + "compute/Compute.sys.mjs");
        const result = await attachCompute(this, this.cfg, row => this.emit(row));
        if (typeof result === "function") {
          this.stopCompute = result;
        } else if (result?.supported === false) {
          return {armed: false, unsupported: true};
        } else if (typeof result?.stop === "function") {
          this.stopCompute = () => result.stop();
        } else {
          throw new Error("invalid native compute teardown");
        }
      }
      this.armed = true;
      return {armed: true};
    }
    if (name === "Stop" && this.started && !this.stopped) {
      this.stopped = true;
      const compute = this.stopCompute ? await this.stopCompute() : null;
      this.stopCompute = null;
      this.armed = false;
      let limit = this.limit;
      let failures = 0;
      if (compute) {
        const counters = [compute.entered, compute.completed, compute.dropped, compute.abandoned, compute.failures];
        if (compute.attached !== true || counters.some(n => !Number.isSafeInteger(n) || n < 0 || n > 0xffffffff)) {
          throw new Error("invalid native compute drain counters");
        }
        limit = Math.min(0xffffffff, limit + compute.dropped);
        failures = Math.min(0xffffffff, compute.abandoned + compute.failures);
        if (compute.entered + compute.completed !== this.sent && !limit && !this.invalid) {
          throw new Error("native compute and actor drain counters disagree");
        }
      }
      return {sent: this.sent, invalid: this.invalid, limit, failures};
    }
    throw new Error("native telemetry child received unexpected control");
  }

  didDestroy() {
    this.armed = false;
    this.stopCompute?.();
    this.stopCompute = null;
  }
}
