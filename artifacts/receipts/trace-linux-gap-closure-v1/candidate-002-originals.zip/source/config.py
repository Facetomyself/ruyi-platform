"""Linux launcher's operator-only configuration checks."""
import json
import os
from pathlib import Path
import re
import stat

MODES = ("jscall", "wasm", "http", "websocket")
FIXED = frozenset(("schema", "origin", "runId", "mode", "enabled", "profile"))
OPTIONAL = {
    "jscall": frozenset(("scriptPath", "functionName", "jsStartLine", "jsStartColumn")),
    "wasm": frozenset(("scriptPath", "functionName", "wasmFunctionIndex", "wasmModuleHash", "wasmEntryOffset", "wasmCompileLine")),
    "http": frozenset(("httpPath",)),
    "websocket": frozenset(("websocketPath",)),
}
ORIGIN = re.compile(r"http://127\.0\.0\.1:([1-9][0-9]{0,4})", re.ASCII)
PATH = re.compile(r"/[A-Za-z0-9._-]+(?:/[A-Za-z0-9._-]+)*", re.ASCII)


def natural(value, maximum):
    return type(value) is int and 0 <= value <= maximum


def private_dir(p):
    p = Path(p)
    if not p.is_absolute() or p.resolve(strict=True) != p:
        raise ValueError("absolute canonical directory required")
    s = p.lstat()
    if not stat.S_ISDIR(s.st_mode) or stat.S_IMODE(s.st_mode) != 0o700 or s.st_uid != os.geteuid():
        raise ValueError("a directory owned by the browser user with mode 0700 is required")
    return p


def unique(items):
    record = {}
    for key, value in items:
        if key in record:
            raise ValueError("duplicate configuration key")
        record[key] = value
    return record


def bounded_path(value):
    return (type(value) is str and len(value) <= 96 and PATH.fullmatch(value)
            and not any(part in (".", "..") for part in value.split("/")))


def load_config(directory, url):
    directory = private_dir(directory)
    fd = os.open(directory / "native-config.json", os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, "rb") as f:
        s = os.fstat(f.fileno())
        if not stat.S_ISREG(s.st_mode) or stat.S_IMODE(s.st_mode) != 0o600 or s.st_uid != os.geteuid() or s.st_nlink != 1:
            raise ValueError("native-config.json must be a private, single-linked operator file (0600)")
        raw = f.read(4097)
    if len(raw) > 4096:
        raise ValueError("native configuration exceeds 4096 bytes")
    c = json.loads(raw.decode("utf-8"), object_pairs_hook=unique)
    if type(c) is not dict or not all(k in c for k in FIXED) or type(c["mode"]) is not str or c["mode"] not in OPTIONAL:
        raise ValueError("unrecognized native configuration")
    mode = c["mode"]
    if c.keys() - (FIXED | OPTIONAL[mode]) or type(c["enabled"]) is not bool or type(c["schema"]) is not int or c["schema"] != 1:
        raise ValueError("unrecognized native configuration fields")
    origin = ORIGIN.fullmatch(c["origin"]) if type(c["origin"]) is str else None
    if not origin or not 1024 <= int(origin[1]) <= 65535 or url != c["origin"] + "/harness":
        raise ValueError("URL must be the configured literal HTTP loopback origin plus /harness")
    if type(c["runId"]) is not str or not re.fullmatch(r"[0-9a-f]{32}", c["runId"]):
        raise ValueError("runId must consist of 32 lowercase hex digits")
    if mode in ("jscall", "wasm"):
        if not bounded_path(c.get("scriptPath")) or c.get("functionName") not in ({"fixedAdd"} if mode == "jscall" else {"add", "trap"}):
            raise ValueError("invalid approved target script/function")
    if mode == "jscall" and (not natural(c.get("jsStartLine"), 65535) or not c["jsStartLine"]
                            or not natural(c.get("jsStartColumn"), 65535) or not c["jsStartColumn"]):
        raise ValueError("invalid approved JS script coordinates")
    if mode == "wasm" and (c.get("wasmFunctionIndex") != 0 or type(c.get("wasmFunctionIndex")) is not int
                           or not natural(c.get("wasmEntryOffset"), 0x100000) or c["wasmEntryOffset"] < 8
                           or not natural(c.get("wasmCompileLine"), 65535) or not c["wasmCompileLine"]
                           or type(c.get("wasmModuleHash")) is not str or not re.fullmatch(r"[0-9a-f]{16}", c["wasmModuleHash"])):
        raise ValueError("invalid approved Wasm function identity")
    if mode == "http" and c.get("httpPath") not in ("/qa-http", "/qa-redirect", "/qa-cache"):
        raise ValueError("invalid approved HTTP path")
    if mode == "websocket" and c.get("websocketPath") != "/qa-ws":
        raise ValueError("invalid approved WebSocket path")
    if type(c["profile"]) is not str:
        raise ValueError("invalid profile path")
    profile = private_dir(c["profile"])
    if profile == directory or profile in directory.parents or any(profile.iterdir()):
        raise ValueError("a separate, fresh profile directory is required")
    # The owner is the controller. Reject leftovers before exec; Gecko also claims its own exclusive writer.
    if any(p.name.startswith("native-") and p.name != "native-config.json" for p in directory.iterdir()):
        raise ValueError("fresh native run directory required")
    return c
