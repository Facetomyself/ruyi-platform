#!/usr/bin/env bash
# Run only inside the dedicated native build OCI bundle.
set -euo pipefail
umask 077
w=$1 arch=$2 phase=$3
src=$w/src obj=$w/obj-wasi159 inputs=$w/inputs logs=/lane-logs stage=/lane-stage
pin=9a2dc53c369c7ae5172018b35988e1d2ffeff402
[[ $(uname -m) == "$arch" && $(realpath -e "$src") == "$src" && $(realpath -e "$obj") == "$obj" ]]
[[ $(awk '/^Seccomp:/ {print $2}' /proc/self/status) == 2 && $(awk '/^NoNewPrivs:/ {print $2}' /proc/self/status) == 1 ]]
[[ $(awk -F: 'NR>2 {gsub(/ /,"",$1);print $1}' /proc/net/dev) == lo ]]
[[ $phase == canary || $phase == patch-objects || $phase == candidate ]]
exec > >(tee "$logs/$phase.log") 2>&1
step=preflight
started=$(date -u +%FT%TZ)
mark() { step=$1; printf '%s %s %s\n' "$(date -u +%FT%TZ)" "$phase" "$step" >> "$logs/phases.log"; }
rollback_patch=''
fin() {
  rc=$?
  if [[ -n $rollback_patch ]]; then
    if git -C "$src" apply --reverse --check "$rollback_patch" && git -C "$src" apply --reverse "$rollback_patch"; then
      printf '%s %s reviewed trial source patch reversed\n' "$(date -u +%FT%TZ)" "$phase" >> "$logs/phases.log"
    else
      rc=88
    fi
  fi
  printf '%s %s %s %s started=%s\n' "$(date -u +%FT%TZ)" "$phase" "$step" "$rc" "$started" >> "$logs/result.log"
  exit "$rc"
}
trap fin EXIT
mark preflight
export GIT_CONFIG_NOSYSTEM=1 GIT_CONFIG_GLOBAL=/dev/null GIT_OPTIONAL_LOCKS=0
export MOZCONFIG="$inputs/tests/linux/host185-audited.mozconfig" RUYITRACE_OBJDIR="$obj"
export RUYITRACE_WASI_SYSROOT="$w/wasi/sysroot-wasm32-wasi" RUYITRACE_BUILD_JOBS=1
export PIP_NO_INDEX=1 PIP_NO_CACHE_DIR=1 PIP_DISABLE_PIP_VERSION_CHECK=1
export MOZBUILD_STATE_PATH=/root/.mozbuild CARGO_BUILD_JOBS=1 CARGO_INCREMENTAL=0 XZ_DEFAULTS=-T1
if [[ -d /root/wheels ]]; then export PIP_FIND_LINKS=/root/wheels; fi
src_rev=$(git -C "$src" rev-parse HEAD)
[[ $src_rev == "$pin" ]]
export MOZ_BUILD_DATE=$(awk '/^#define MOZ_BUILDID/ {print $3}' "$obj/buildid.h")
[[ $MOZ_BUILD_DATE =~ ^[0-9]{14}$ ]]
lib=$obj/dist/bin/libxul.so
archive=$obj/$arch-unknown-linux-gnu/release/libgkrust.a
{
  date -u +%FT%TZ
  uname -m
  awk '/^Seccomp:|^NoNewPrivs:|^CapEff:/' /proc/self/status
  printf 'canonical_source %s\ncanonical_obj %s\nsource_revision %s\nsource_tree %s\nupstream_build_id %s\n' "$src" "$obj" "$src_rev" "$(git -C "$src" rev-parse 'HEAD^{tree}')" "$MOZ_BUILD_DATE"
  clang-19 --version
  ld.lld --version
  rustc -vV
  cargo -vV
  cbindgen --version
  python3 --version
  sha256sum "$(readlink -f /usr/bin/clang-19)" "$(realpath "$(command -v ld.lld)")" "$(rustup which rustc)" "$(rustup which cargo)" /root/.cargo/bin/cbindgen
  df -B1 "$src" "$obj" "$logs"
} > "$logs/$phase-toolchain.txt"
python3 -B "$inputs/tests/linux/check_configured_core.py" "$src" "$obj" --arch "$arch" > "$logs/$phase-configured.json"
if [[ $phase == candidate ]]; then
  test -s "$logs/canary-object.sha256"
  cp -- "$logs/canary-baseline.sha256" "$logs/candidate-baseline.sha256"
else
  sha256sum "$archive" "$lib" > "$logs/$phase-baseline.sha256"
fi
cd "$src"
if [[ $phase == canary ]]; then
  mark websocket_object_canary
  wsobj=$obj/netwerk/protocol/websocket
  unit_src=$(awk '/^#include "[^"]*\/WebSocketChannel[.]cpp"$/ {print FILENAME}' "$wsobj"/Unified_cpp_protocol_websocket*.cpp)
  [[ $unit_src =~ ^$wsobj/Unified_cpp_protocol_websocket[0-9]+\.cpp$ ]]
  unit=${unit_src%.cpp}.o
  before=missing
  [[ ! -f $unit ]] || before=$(stat -c '%y' "$unit")
  gmake -j1 -C "$wsobj" -W "${unit_src##*/}" "${unit##*/}"
  [[ $(stat -c '%y' "$unit") != "$before" ]]
  sha256sum "$unit" > "$logs/canary-object.sha256"
  llvm-readelf -h "$unit" > "$logs/canary-object-elf.txt"
  sha256sum -c "$logs/$phase-baseline.sha256"
  mark configured_and_compiled
  exit 0
fi

mark apply_reviewed_patch
patch=$stage/gecko159-websocket-metadata.patch
expected_file=$stage/patch.sha256
if [[ $phase == patch-objects ]]; then
  patch=$stage/gecko159-websocket-metadata-trial.patch
  expected_file=$stage/trial-patch.sha256
fi
expected=$(< "$expected_file")
[[ $expected =~ ^[a-f0-9]{64}$ && $(sha256sum "$patch" | cut -d' ' -f1) == "$expected" ]]
git apply --numstat "$patch" | awk -F '\t' 'NF != 3 || $3 !~ /^netwerk\/protocol\/websocket\/[A-Za-z0-9_.-]+$/ { bad=1 } END { if (NR == 0 || bad) exit 1 }'
git apply --summary "$patch"
if git apply --reverse --check "$patch" 2>/dev/null; then
  [[ $phase == candidate && -e $logs/candidate-source-patched && $(< "$logs/candidate-source-patched") == "$expected" ]]
else
  git apply --check "$patch"
  git apply "$patch"
fi
if [[ $phase == patch-objects ]]; then
  rollback_patch=$patch
else
  printf '%s\n' "$expected" > "$logs/candidate-source-patched"
fi
git apply --reverse --check "$patch"
sha256sum "$patch" > "$logs/$phase-gecko-patch.sha256"
git diff --check -- netwerk/protocol/websocket
git --no-pager diff --binary HEAD -- netwerk/protocol/websocket > "$logs/$phase-gecko-websocket-effective.diff"
if [[ $phase == patch-objects ]]; then
  mark compile_patched_websocket_objects
  ./mach build -j1 --allow-subdirectory-build netwerk/protocol/websocket
  sha256sum "$obj"/netwerk/protocol/websocket/Unified_cpp_protocol_websocket*.o > "$logs/trial-websocket-objects.sha256"
  sha256sum -c "$logs/$phase-baseline.sha256"
  mark patched_objects_compiled_without_link
  exit 0
fi

mark native_incremental_build
# Let the generated build graph own IDL, IPDL, exports, dependent C++ and the link.
# XPIDL can invalidate Rust XPCOM and gkrust. Preserve the original bounded ARM edge.
audit_flags=()
if [[ $arch == aarch64 ]]; then
  export RUSTC_WRAPPER="$inputs/tests/linux/arm64_gkrust_wrapper.py"
  export RUYITRACE_ARM64_OBJDIR="$obj" RUYITRACE_ARM64_WRAPPER_RECEIPT="$w/candidate-attempt/gkrust-wrapper.json"
  test -x "$RUSTC_WRAPPER"
  audit_flags+=(--thin-receipt "$RUYITRACE_ARM64_WRAPPER_RECEIPT")
fi
./mach build -j1
candidate_sha=$(sha256sum "$lib" | cut -d' ' -f1)
baseline_sha=$(awk -v x="$lib" '$2 == x {print $1}' "$logs/candidate-baseline.sha256")
[[ $candidate_sha =~ ^[a-f0-9]{64}$ && $candidate_sha != "$baseline_sha" ]]
printf '%s  %s\n' "$candidate_sha" "$lib" > "$logs/relinked-libxul.sha256"
llvm-readelf -h -n "$lib" > "$logs/relinked-libxul-elf.txt"

mark upstream_rust_networking_audit
# This original checker invokes upstream check_binary --networking, which rehashes the very same archive before and after audit.
# Audit the retained baseline separately when available and replay on the actual linked archive.
python3 -B "$inputs/tests/linux/audit_core_archive.py" "$src" "$obj" "$w/candidate-attempt/candidate-archive-audit.json" --arch "$arch" "${audit_flags[@]}"
sha256sum "$archive" > "$logs/candidate-gkrust.sha256"

mark mach_package
# The package pointer/old package are lower-layer artifacts in overlay mode, or private copies.
# Clear only these verified paths in the private object mount so the new package proves fresh output.
[[ $(realpath -e "$obj/dist") == "$obj/dist" ]]
pointer=$obj/dist/package_name.txt
if [[ -e $pointer || -L $pointer ]]; then
  [[ -f $pointer && ! -L $pointer && $(realpath -e "$pointer") == "$pointer" ]]
  old=$(< "$pointer")
  [[ $old =~ ^firefox-[a-zA-Z0-9_.-]+\.tar\.xz$ ]]
  old_archive=$obj/dist/$old
  if [[ -e $old_archive || -L $old_archive ]]; then
    [[ -f $old_archive && ! -L $old_archive && $(realpath -e "$old_archive") == "$old_archive" ]]
    rm -- "$old_archive"
  fi
  rm -- "$pointer"
fi
./mach package
[[ -f $pointer && ! -L $pointer && $(realpath -e "$pointer") == "$pointer" ]]
name=$(< "$pointer")
[[ $name =~ ^firefox-[a-zA-Z0-9_.-]+\.tar\.xz$ ]]
package=$obj/dist/$name
[[ -s $package && ! -L $package && $(realpath -e "$package") == "$package" ]]
ln "$package" "$logs/$name" 2>/dev/null || cp --reflink=auto "$package" "$logs/$name"
mark package_readback
python3 -B "$stage/package-readback.py" "$logs/$name" --stage "$obj/dist/firefox" --linked "$lib" --arch "$arch" > "$logs/candidate-package.json"
printf '%s\n' "$name" > "$logs/candidate-name"
mark package_verified
