import {LIMIT} from "resource://gre/modules/ruyi-native/Policy.sys.mjs";

export function fileAt(dir, name) {
  const f = dir.clone();
  f.append(name);
  return f;
}

export function checkedDir(path) {
  const f = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
  f.initWithPath(path);
  f.normalize();
  if (f.path !== path || f.isSymlink() || !f.isDirectory() || (f.permissions & 0o777) !== 0o700) {
    throw new Error("invalid private native runtime directory");
  }
  return f;
}

export function control(dir, name) {
  const f = fileAt(dir, "native-" + name);
  let symlink;
  try {
    symlink = f.isSymlink();
  } catch (error) {
    if (error.result === Cr.NS_ERROR_FILE_NOT_FOUND) {
      return false;
    }
    throw error;
  }
  if (symlink || !f.isFile() || (f.permissions & 0o777) !== 0o600 || f.fileSize !== 0) {
    throw new Error("invalid native telemetry control file");
  }
  return true;
}

async function exclusiveWrite(dir, name, text) {
  const final = fileAt(dir, name);
  const staging = fileAt(dir, `${name}.pending`);
  staging.create(Ci.nsIFile.NORMAL_FILE_TYPE, 0o600);
  await IOUtils.writeUTF8(staging.path, text, {flush: true});
  staging.permissions = 0o400;
  await IOUtils.move(staging.path, final.path, {noOverwrite: true});
}

function nativeTransport() {
  function boolPref(key) {
    return Services.prefs.getPrefType(key) === Ci.nsIPrefBranch.PREF_BOOL ? Services.prefs.getBoolPref(key) : null;
  }
  let launched = null;
  try {
    if (typeof Services.io.socketProcessLaunched === "boolean") {
      launched = Services.io.socketProcessLaunched;
    }
  } catch {
    // Older or unavailable IO service implementations have no launch observation.
  }
  // Observations only: the native producer independently gates support on its effective transport.
  return {
    socketProcessEnabled: boolPref("network.process.enabled"),
    httpNetworkAccessOnSocketProcessEnabled: boolPref("network.http.network_access_on_socket_process.enabled"),
    forceUseSocketProcessEnvPresent: Services.env.exists("MOZ_FORCE_USE_SOCKET_PROCESS"),
    socketProcessLaunched: launched,
  };
}

export class Writer {
  constructor(dir, c) {
    // Exclusive create by the browser parent; a second Firefox cannot claim the same run.
    fileAt(dir, "native-writer.lock").create(Ci.nsIFile.NORMAL_FILE_TYPE, 0o400);
    this.dir = dir;
    this.scope = Object.freeze({schema: 1, runId: c.runId, origin: c.origin, mode: c.mode,
      documentPath: c.documentPath, enabled: c.enabled, writerPid: Services.appinfo.processID});
    this.rows = [];
    this.drops = {invalid: 0, scope: 0, limit: 0, protocol: 0, io: 0};
  }

  count(drop) {
    this.drops[drop] = Math.min(0xffffffff, this.drops[drop] + 1);
  }

  async setScope(actor) {
    const {manager, browsingContext} = actor;
    if (this.scope.contentPid || manager.osPid <= 0 || !browsingContext.id) {
      throw new Error("invalid native telemetry scope");
    }
    this.scope = Object.freeze({...this.scope, contentPid: manager.osPid,
      browsingContextId: browsingContext.id, innerWindowId: manager.innerWindowId});
    await this.receipt("ready");
  }

  append(row) {
    if (this.rows.length >= LIMIT) {
      this.count("limit");
      return;
    }
    const line = JSON.stringify({...row, seq: this.rows.length + 1});
    if (line.length > 256) {
      this.count("invalid");
      return;
    }
    this.rows.push(line);
  }

  receipt(state, data = {}) {
    return exclusiveWrite(this.dir, `native-${state}.json`, JSON.stringify({...this.scope, state, ...data}) + "\n");
  }

  async seal(status, barrier) {
    try {
      await exclusiveWrite(this.dir, "native-events.jsonl",
        [JSON.stringify({...this.scope, state: "header"}), ...this.rows, ""].join("\n"));
    } catch (e) {
      this.count("io");
      Cu.reportError(e);
    }
    const complete = status === "ok" && Object.values(this.drops).every(n => n === 0);
    const transport = this.scope.mode === "websocket" ? {nativeTransport: nativeTransport()} : {};
    await this.receipt("sealed", {complete, status: complete || status === "unsupported" ? status : "partial",
      accepted: this.rows.length, drops: this.drops, ...barrier, ...transport});
  }
}
