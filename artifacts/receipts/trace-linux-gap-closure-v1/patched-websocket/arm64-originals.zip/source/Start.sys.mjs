import {ACTOR, LIMIT, ROOT, allowedDocument, validatedConfig, validatedRow} from "resource://gre/modules/ruyi-native/Policy.sys.mjs";
import {Writer, checkedDir, control} from "resource://gre/modules/ruyi-native/Writer.sys.mjs";
import {clearInterval, clearTimeout, setInterval, setTimeout} from "resource://gre/modules/Timer.sys.mjs";

export let session = null;

export function boot() {
  const directory = Services.env.get("MOZ_RUYITRACE_NATIVE_DIR");
  const raw = Services.env.get("MOZ_RUYITRACE_NATIVE_CONFIG");
  if (session || !directory || !raw || raw.length > 4096 ||
      Services.appinfo.processType !== Ci.nsIXULRuntime.PROCESS_TYPE_DEFAULT) {
    return;
  }
  const cfg = validatedConfig(JSON.parse(raw));
  if (!cfg) {
    throw new Error("invalid native telemetry startup configuration");
  }
  const dir = checkedDir(directory);
  const profile = checkedDir(cfg.profile);
  if (dir.equals(profile) || !Services.dirsvc.get("ProfD", Ci.nsIFile).equals(profile)) {
    throw new Error("native telemetry startup profile mismatch");
  }
  session = new Session(dir, cfg);
  ChromeUtils.registerWindowActor(ACTOR, {
    parent: {esModuleURI: ROOT + "RuyiNativeTelemetryParent.sys.mjs"},
    child: {esModuleURI: ROOT + "RuyiNativeTelemetryChild.sys.mjs"},
    // MatchPattern excludes the port; both actor sides verify exact origin and document URL.
    matches: [`http://127.0.0.1${cfg.documentPath}`],
    remoteTypes: ["webIsolated"],
    safeForUntrustedWebProcess: true,
    allFrames: false,
  });
}

function timed(promise, ms = 5000) {
  let timeout;
  return Promise.race([promise, new Promise((resolve, reject) => {
    timeout = setTimeout(() => reject(new Error("native telemetry actor timeout")), ms);
  })]).finally(() => clearTimeout(timeout));
}

class Session {
  constructor(dir, cfg) {
    this.dir = dir;
    this.cfg = cfg;
    this.writer = new Writer(dir, cfg);
    this.state = "waiting";
    this.childSeen = 0;
    this.childSent = null;
    this.timer = setInterval(() => this.tick(), 75);
    this.deadline = ChromeUtils.now() + 120000;
  }

  scoped(actor) {
    if (!actor || (this.actor && actor !== this.actor)) {
      return false;
    }
    const {manager, browsingContext} = actor;
    return manager && !manager.isClosed && manager.isCurrentGlobal &&
      !manager.isInProcess && !manager.isInitialDocument &&
      allowedDocument(browsingContext, manager.documentPrincipal, manager.documentURI, this.cfg.origin, this.cfg.documentPath);
  }

  async findWindow() {
    let found = null;
    const windows = Services.wm.getEnumerator("navigator:browser");
    while (windows.hasMoreElements()) {
      const window = windows.getNext();
      for (const tab of window.gBrowser?.tabs ?? []) {
        const manager = tab.linkedBrowser?.browsingContext?.currentWindowGlobal;
        const context = manager?.browsingContext;
        if (!manager || manager.isClosed || !manager.isCurrentGlobal || manager.isInProcess ||
            !allowedDocument(context, manager.documentPrincipal, manager.documentURI, this.cfg.origin, this.cfg.documentPath)) {
          continue;
        }
        if (found) {
          this.fail(new Error("ambiguous native telemetry scope"), "scope");
          return;
        }
        found = manager;
      }
    }
    if (!found) {
      return;
    }
    this.state = "preparing";
    try {
      const actor = found.getActor(ACTOR);
      const reply = await timed(actor.sendQuery("Ready", this.cfg), 2500);
      if (reply?.ready !== true || !this.scoped(actor)) {
        this.state = "waiting";
        return;
      }
      this.actor = actor;
      await this.writer.setScope(actor);
      this.state = "ready";
    } catch (e) {
      this.fail(e);
    }
  }

  onMessage(actor, name, data) {
    if (this.actor !== actor) {
      return;
    }
    if (name === "Row") {
      if (this.childSeen >= LIMIT) {
        this.writer.count("limit");
        return;
      }
      this.childSeen++;
      this.row(actor, data, true);
    } else {
      this.writer.count("protocol");
    }
  }

  row(actor, data, child) {
    if (!this.scoped(actor)) {
      this.writer.count("scope");
      return;
    }
    if (!this.cfg.enabled || !["starting", "armed", "draining"].includes(this.state) ||
        child !== ["jscall", "wasm"].includes(this.cfg.mode)) {
      this.writer.count("protocol");
      return;
    }
    const row = validatedRow(this.cfg, data);
    if (!row) {
      this.writer.count("invalid");
      return;
    }
    this.writer.append(row);
  }

  tick() {
    if (["sealing", "sealed", "starting", "draining", "preparing"].includes(this.state)) {
      return;
    }
    try {
      if (ChromeUtils.now() >= this.deadline) {
        this.fail(new Error("native telemetry session deadline"));
      } else if (this.state === "waiting") {
        this.findWindow().catch(e => this.fail(e));
      } else if (["ready", "armed"].includes(this.state) && !this.scoped(this.actor)) {
        this.fail(new Error("native telemetry window left approved scope"), "scope");
      } else if (this.state === "ready" && control(this.dir, "start")) {
        this.start();
      } else if (this.state === "armed" && control(this.dir, "stop")) {
        this.stop();
      }
    } catch (e) {
      this.fail(e);
    }
  }

  async start() {
    this.state = "starting";
    try {
      const reply = await timed(this.actor.sendQuery("Start", null));
      if (reply?.unsupported === true) {
        return this.seal("unsupported");
      }
      if (!reply || Object.keys(reply).length !== 1 || reply.armed !== true || !this.scoped(this.actor)) {
        throw new Error("native telemetry arm acknowledgement missing");
      }
      if (this.cfg.enabled && ["http", "websocket"].includes(this.cfg.mode)) {
        const {attachNetwork} = ChromeUtils.importESModule(ROOT + "net/Network.sys.mjs");
        const result = await timed(attachNetwork(this.actor, this.cfg, row => this.row(this.actor, row, false)));
        if (result?.supported === false) {
          return this.seal("unsupported");
        }
        if (typeof result === "function") {
          this.stopNetwork = result;
        } else if (typeof result?.stop === "function") {
          this.stopNetwork = () => result.stop();
        } else {
          throw new Error("invalid native network teardown");
        }
      }
      await this.writer.receipt("armed");
      this.state = "armed";
    } catch (e) {
      if (e?.code === "NS_RUYI_UNSUPPORTED") {
        return this.seal("unsupported");
      }
      this.fail(e);
    }
  }

  async stop() {
    this.state = "draining";
    try {
      const network = await timed(this.stopNetwork?.());
      this.stopNetwork = null;
      const bounded = n => Number.isSafeInteger(n) && n >= 0 && n <= 0xffffffff;
      if (network) {
        if (![network.limit, network.failures].every(bounded)) {
          throw new Error("invalid native network drain counters");
        }
        this.writer.drops.limit = Math.min(0xffffffff, this.writer.drops.limit + network.limit);
        this.writer.drops.protocol = Math.min(0xffffffff, this.writer.drops.protocol + network.failures);
      }
      // JSWindowActor async Row messages and this query reply share the same actor channel.
      // The child stops its own observer before replying; count agreement is independently checked.
      const reply = await timed(this.actor.sendQuery("Stop", null));
      if (!reply || Object.keys(reply).length !== 4 ||
          ![reply.sent, reply.limit, reply.invalid, reply.failures].every(bounded) || reply.sent !== this.childSeen ||
          !this.scoped(this.actor)) {
        throw new Error("native telemetry drain acknowledgement mismatch");
      }
      this.childSent = reply.sent;
      this.writer.drops.limit = Math.min(0xffffffff, this.writer.drops.limit + reply.limit);
      this.writer.drops.invalid = Math.min(0xffffffff, this.writer.drops.invalid + reply.invalid);
      this.writer.drops.protocol = Math.min(0xffffffff, this.writer.drops.protocol + reply.failures);
      this.seal("ok");
    } catch (e) {
      this.fail(e);
    }
  }

  fail(error, drop = "protocol") {
    this.writer.count(drop);
    console.error("Ruyi native telemetry stopped before a complete seal:", error);
    this.seal("partial");
  }

  async seal(status) {
    if (["sealing", "sealed"].includes(this.state)) {
      return;
    }
    this.state = "sealing";
    clearInterval(this.timer);
    try {
      await this.writer.seal(status, {childSent: this.childSent, childSeen: this.childSeen});
    } catch (e) {
      Cu.reportError(e);
    } finally {
      this.state = "sealed";
      Services.startup.quit(Ci.nsIAppStartup.eAttemptQuit);
    }
  }
}
