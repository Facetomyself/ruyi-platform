import {session} from "resource://gre/modules/ruyi-native/Start.sys.mjs";

export class RuyiNativeTelemetryParent extends JSWindowActorParent {
  receiveMessage({name, data}) {
    session?.onMessage(this, name, data);
  }
}
