// Product JSCall/Wasm source. Only a trusted child JSWindowActor calls this.
// No logic or wrappers are injected into the debuggee.

const activeActors = new WeakMap();
const MAX_CALLS = 256;
const MAX_U32 = 0xffffffff;

// The first product scope is limited to two synthetic fixtures. A detached
// offline test verifies each complete SHA-256, the Gecko SHA-1 prefix, the
// actual export index, and the native trap offset from the pinned bytes.
const WASM_PATH = "/target.js";
const WASM_COMPILE_LINE = 31;
const WASM_MODULES = Object.freeze({
  add: Object.freeze({
    sha256: "f61fd62f57c41269c3c23f360eeaf1090b1db9c38651106674d48bc65dba88ba",
    hash: "f2f415504deccd0e", functionIndex: 0, entryOffset: 35,
  }),
  trap: Object.freeze({
    sha256: "77b3dd4987550501c5bd40138997cf63798dea1c1f8d5c50c6bbc5405ee2798a",
    hash: "14de952378bf4340", functionIndex: 0, entryOffset: 33,
  }),
});

function loopbackOrigin(value) {
  if (typeof value !== "string") {
    return false;
  }
  const match = /^http:\/\/(?:127\.0\.0\.1|\[::1\])(?::([1-9][0-9]{0,4}))?$/.exec(value);
  // Require exactly the URI serialization Gecko uses for principal origins.
  return !!match && Number(match[1] ?? 0) <= 65535 && new URL(value).origin === value;
}

function uint(value, minimum = 0) {
  return Number.isInteger(value) && value >= minimum && value <= MAX_U32;
}

function safePath(value) {
  return (
    typeof value === "string" &&
    value.length <= 192 &&
    /^\/(?:[A-Za-z0-9_-][A-Za-z0-9_.-]*\/)*[A-Za-z0-9_-][A-Za-z0-9_.-]*\.m?js$/.test(value)
  );
}

function matchesWindow(actor, manager, win, doc, principal, origin) {
  try {
    return (
      manager !== null &&
      manager === actor.manager &&
      manager.isCurrentGlobal &&
      !manager.isClosed &&
      !manager.browsingContext.parent &&
      win !== null &&
      win === actor.contentWindow &&
      win.windowGlobalChild === manager &&
      doc !== null &&
      doc === actor.document &&
      doc === win.document &&
      principal === doc.nodePrincipal &&
      principal.isContentPrincipal &&
      principal.origin === origin &&
      doc.documentURIObject.prePath === origin
    );
  } catch {
    // Window teardown can invalidate a WindowProxy or its document getter.
    return false;
  }
}

function matchesJS(script, url) {
  if (script?.format !== "js") {
    return false;
  }
  const { source } = script;
  // The actual compiled filename is source.url, rather than displayURL
  // (which a sourceURL directive can set) or an eval's introducer filename.
  if (source.url !== url) {
    return false;
  }
  const type = source.introductionType;
  return type === "srcScript" || type === "importedModule";
}

const notAttached = () => ({
  attached: false,
  entered: 0,
  completed: 0,
  dropped: 0,
  abandoned: 0,
  failures: 0,
});

/**
 * Observe one current, top-level, literal HTTP-loopback Window. cfg and emit
 * are supplied by chrome code, never page data. Return an idempotent detach
 * function whose snapshot accounts for recognized/dropped/incomplete calls.
 * A valid disabled or ineligible Window returns an unattached zero snapshot.
 * An enabled eligible Window with an invalid selector/setup fails explicitly.
 */
export function attachCompute(actor, cfg, emit) {
  if (cfg?.enabled !== true || !loopbackOrigin(cfg.origin)) {
    return notAttached;
  }

  const { origin, mode, runId, scriptPath, functionName } = cfg;
  const manager = actor.manager;
  const win = actor.contentWindow;
  const doc = actor.document;
  const principal = doc?.nodePrincipal;
  if (!matchesWindow(actor, manager, win, doc, principal, origin)) {
    return notAttached;
  }
  if (activeActors.has(actor)) {
    throw new Error("compute already attached to actor");
  }

  const { jsStartLine, jsStartColumn, wasmCompileLine, wasmEntryOffset, wasmFunctionIndex, wasmModuleHash } = cfg;
  const wasm = mode === "wasm";
  const manifest = wasm && typeof functionName === "string" && Object.hasOwn(WASM_MODULES, functionName)
    ? WASM_MODULES[functionName]
    : null;
  if (
    !safePath(scriptPath) ||
    typeof runId !== "string" || !/^[A-Za-z0-9_-]{1,96}$/.test(runId) ||
    typeof functionName !== "string" || !/^[A-Za-z_$][A-Za-z0-9_$]{0,63}$/.test(functionName) ||
    typeof emit !== "function" ||
    (mode !== "jscall" && mode !== "wasm") ||
    (mode === "jscall" && (!uint(jsStartLine, 1) || !uint(jsStartColumn, 1))) ||
    (wasm && (!manifest || scriptPath !== WASM_PATH || wasmCompileLine !== WASM_COMPILE_LINE ||
      wasmModuleHash !== manifest.hash || wasmEntryOffset !== manifest.entryOffset ||
      wasmFunctionIndex !== manifest.functionIndex))
  ) {
    throw new Error("invalid compute selector");
  }

  const scriptURL = `${origin}${scriptPath}`;
  const wasmURL = wasm
    ? `wasm:${encodeURI(`${scriptURL} line ${WASM_COMPILE_LINE} > WebAssembly.Module`)}:${manifest.hash}`
    : null;
  const activeFrames = new Set();
  const modules = new WeakMap();
  const status = { ...notAttached(), attached: true };
  const functionKind = wasm ? "wasm" : "js";
  let nextModuleId = 1;
  let detached = false;
  let dbg;
  const stillCurrent = () => !detached && matchesWindow(actor, manager, win, doc, principal, origin);

  function detach() {
    if (!detached) {
      detached = true;
      activeActors.delete(actor);
      status.abandoned += activeFrames.size;
      for (const frame of activeFrames) {
        try {
          frame.onPop = undefined;
        } catch {
          status.failures++;
        }
      }
      activeFrames.clear();
      if (dbg) {
        try {
          dbg.onEnterFrame = undefined;
          dbg.removeAllDebuggees();
        } catch {
          status.failures++;
        }
        dbg = null;
      }
    }
    return { ...status };
  }

  try {
    // This component is the Gecko implementation of SpiderMonkey Debugger.
    // Initialize it in the privileged module realm, never the Window's realm.
    if (!globalThis.Debugger) {
      Cc["@mozilla.org/jsdebugger;1"].createInstance(Ci.IJSDebugger).addClass(globalThis);
    }
    dbg = new globalThis.Debugger();
    const debuggee = dbg.addDebuggee(win);
    dbg.onEnterFrame = frame => {
      let registered = false;
      try {
        if (frame.type !== (wasm ? "wasmcall" : "call")) {
          return;
        }
        const { script } = frame;
        if (wasm) {
          // Trusted fixture manifest binds this native enter trap's bytecode
          // offset to its actual exported function index. The synthetic
          // module fingerprint comes from the C++ Debugger.Source getter.
          if (script?.format !== "wasm" || frame.offset !== manifest.entryOffset || script.source.url !== wasmURL) {
            return;
          }
          const caller = frame.older;
          if (!caller || caller.type === "wasmcall" || !matchesJS(caller.script, scriptURL) ||
              caller.script.global !== debuggee) {
            return;
          }
        } else if (!matchesJS(script, scriptURL) || script.global !== debuggee ||
          script.startLine !== jsStartLine || script.startColumn !== jsStartColumn ||
          script.isGeneratorFunction || script.isAsyncFunction || frame.callee?.name !== functionName) {
          return;
        }
        if (!stillCurrent()) {
          return;
        }
        if (status.entered >= MAX_CALLS) {
          status.dropped = Math.min(MAX_U32, status.dropped + 1);
          return;
        }

        const call = status.entered + 1;
        const identity = { family: mode, functionKind, call };
        if (wasm) {
          if (!modules.has(script)) {
            modules.set(script, nextModuleId++);
          }
          // Script is an engine Debugger.Script referent for a Wasm instance.
          identity.moduleId = modules.get(script);
          identity.functionIndex = manifest.functionIndex;
        }
        frame.onPop = completion => {
          activeFrames.delete(frame);
          try {
            if (!stillCurrent()) {
              status.abandoned++;
              return;
            }
            // Test only key presence; never read, unwrap, store, or transmit
            // the completion value, exception object, stack, or any arguments.
            const kind = completion === null ? null : Object.hasOwn(completion, "throw")
              ? "throw" : Object.hasOwn(completion, "return") ? "return" : null;
            if (kind === null) {
              status.abandoned++;
              return;
            }
            emit({ ...identity, kind });
            status.completed++;
          } catch {
            status.abandoned++;
            status.failures++;
          }
          // Undefined leaves SpiderMonkey's original completion unchanged.
        };
        activeFrames.add(frame);
        registered = true;
        emit({ ...identity, kind: "enter" });
        status.entered++;
      } catch {
        if (registered) {
          activeFrames.delete(frame);
          try {
            frame.onPop = undefined;
          } catch {
            status.failures++;
          }
        }
        status.failures++;
      }
      // Undefined leaves SpiderMonkey's execution wholly unchanged.
    };
    activeActors.set(actor, detach);
    return detach;
  } catch {
    detach();
    throw new Error("compute Debugger attachment failed");
  }
}
