export const ACTOR = "RuyiNativeTelemetry";
export const ROOT = "resource://gre/modules/ruyi-native/";
export const LIMIT = 4096;
export const DEFAULT_DOCUMENT = "/harness";
const fields = {jscall: ["scriptPath", "functionName", "jsStartLine", "jsStartColumn"],
  wasm: ["scriptPath", "functionName", "wasmFunctionIndex", "wasmModuleHash", "wasmEntryOffset", "wasmCompileLine"],
  http: ["httpPath", "redirectPath"], websocket: ["websocketPath"]};
const common = ["schema", "runId", "origin", "enabled", "profile", "mode", "documentPath"];
const WASM = {add: ["f2f415504deccd0e", 35], trap: ["14de952378bf4340", 33]};
const uint = (n, max = 0xffffffff) => Number.isSafeInteger(n) && n >= 0 && n <= max;
const match = (s, re, max) => typeof s === "string" && s.length <= max && re.exec(s)?.[0] === s;
const boundedPath = s => match(s, /^\/[A-Za-z0-9._-]+(?:\/[A-Za-z0-9._-]+)*$/, 96) &&
  !s.split("/").some(x => x === "." || x === "..");

export function validatedConfig(c) {
  if (!c || Object.getPrototypeOf(c) !== Object.prototype || c.schema !== 1 ||
      typeof c.enabled !== "boolean" || typeof c.mode !== "string" || !Object.hasOwn(fields, c.mode) ||
      !match(c.runId, /^[0-9a-f]{32}$/, 32) ||
      !match(c.origin, /^http:\/\/127\.0\.0\.1:[1-9][0-9]{0,4}$/, 22) ||
      typeof c.profile !== "string" || !c.profile.startsWith("/") || c.profile.length > 512 ||
      Object.keys(c).some(k => !common.includes(k) && !fields[c.mode].includes(k))) {
    return null;
  }
  const port = Number(c.origin.split(":").pop());
  const documentPath = Object.hasOwn(c, "documentPath") ? c.documentPath : DEFAULT_DOCUMENT;
  if (port < 1024 || port > 65535 || !boundedPath(documentPath)) {
    return null;
  }
  if (c.mode === "jscall" && (!boundedPath(c.scriptPath) ||
      !match(c.scriptPath, /^\/(?:[A-Za-z0-9_-][A-Za-z0-9_.-]*\/)*[A-Za-z0-9_-][A-Za-z0-9_.-]*\.m?js$/, 96) ||
      !match(c.functionName, /^[A-Za-z_$][A-Za-z0-9_$]{0,63}$/, 64) ||
      !uint(c.jsStartLine, 65535) || !c.jsStartLine || !uint(c.jsStartColumn, 65535) || !c.jsStartColumn)) {
    return null;
  }
  if (c.mode === "wasm") {
    if (typeof c.functionName !== "string" || !Object.hasOwn(WASM, c.functionName)) {
      return null;
    }
    const [hash, offset] = WASM[c.functionName];
    if (c.scriptPath !== "/target.js" || c.wasmFunctionIndex !== 0 || c.wasmCompileLine !== 31 ||
        c.wasmModuleHash !== hash || c.wasmEntryOffset !== offset) {
      return null;
    }
  }
  if (c.mode === "http" && (!boundedPath(c.httpPath) ||
      (Object.hasOwn(c, "redirectPath") && (!boundedPath(c.redirectPath) || c.redirectPath === c.httpPath)))) {
    return null;
  }
  if (c.mode === "websocket" && !boundedPath(c.websocketPath)) {
    return null;
  }
  return Object.freeze({...c, documentPath});
}

export function allowedDocument(context, principal, uri, origin, documentPath = DEFAULT_DOCUMENT) {
  const attrs = principal?.originAttributes;
  return context && context.top === context && Boolean(principal?.isContentPrincipal) &&
    principal.originNoSuffix === origin && (attrs?.privateBrowsingId ?? 0) === 0 &&
    (attrs?.userContextId ?? 0) === 0 && uri?.scheme === "http" &&
    uri.prePath === origin && uri.spec === origin + documentPath;
}

export function validatedRow(c, r) {
  if (!r || Object.getPrototypeOf(r) !== Object.prototype || r.family !== c.mode ||
      Object.keys(r).length > 7) {
    return null;
  }
  const {family, kind} = r;
  let bounded;
  if (family === "jscall" || family === "wasm") {
    if (!["enter", "return", "throw"].includes(kind) || !uint(r.call, LIMIT) || !r.call ||
        r.functionKind !== (family === "jscall" ? "js" : "wasm")) {
      return null;
    }
    bounded = {family, kind, call: r.call, functionKind: r.functionKind};
    if (family === "wasm") {
      if (r.functionIndex !== c.wasmFunctionIndex || !uint(r.moduleId) || !r.moduleId) {
        return null;
      }
      Object.assign(bounded, {functionIndex: r.functionIndex, moduleId: r.moduleId});
    }
  } else if (family === "http") {
    if (kind !== "transaction" || !uint(r.chain) || !r.chain ||
        r.method !== "GET" || !["network", "cache"].includes(r.transport) ||
        !uint(r.status, 599) || r.status < 100) {
      return null;
    }
    bounded = {family, kind, chain: r.chain, transport: r.transport, method: r.method, status: r.status};
  } else if (family === "websocket") {
    if (kind !== "frame" || !uint(r.connection) || !r.connection ||
        !["rx", "tx"].includes(r.direction) || ![0, 1, 2, 8, 9, 10].includes(r.opcode) ||
        typeof r.fin !== "boolean" || !uint(r.length, 0x100000)) {
      return null;
    }
    bounded = {family, kind, connection: r.connection, direction: r.direction,
      opcode: r.opcode, fin: r.fin, length: r.length};
  }
  return bounded && Object.keys(r).length === Object.keys(bounded).length &&
    Object.keys(r).every(k => Object.hasOwn(bounded, k)) ? bounded : null;
}
