#!/usr/bin/python3 -I
"""Installed by the image builder. Launch only the same bundled Firefox."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import zipfile

sys.path.insert(0, "/opt/ruyitrace-native")
from config import MODES, WASM, initialize, load_config, private_dir, target_url, wasm_fields


def verify():
    raw = Path("/opt/ruyitrace-native/package.json").read_bytes()
    package = json.loads(raw)
    root = Path("/browser")
    inventory = package.get("patched_firefox_inventory")
    wanted = dict(package["package_sha256"])
    if inventory is not None:
        actual_dirs, actual_files = set(), set()
        for path in root.rglob("*"):
            name = path.relative_to(root).as_posix()
            mode = path.lstat().st_mode
            if stat.S_ISDIR(mode):
                actual_dirs.add(name)
            elif stat.S_ISREG(mode):
                actual_files.add(name)
                entry = inventory["files"].get(name)
                if entry is None or stat.S_IMODE(mode) != entry["mode"]:
                    raise ValueError(f"unexpected installed browser file or mode: {name}")
                wanted[name] = entry["sha256"]
            else:
                raise ValueError(f"unexpected installed browser member type: {name}")
        if actual_dirs != set(inventory["directories"]) or actual_files != inventory["files"].keys():
            raise ValueError("installed browser tree differs from the patched archive inventory")
    for name, want in wanted.items():
        with (root / name).open("rb") as f:
            digest = hashlib.file_digest(f, "sha256").hexdigest()
        if digest != want:
            raise ValueError(f"installed browser package digest mismatch: {name}")
    with zipfile.ZipFile("/browser/omni.ja") as z:
        for name, want in {**package["archive_modules"],
                           "modules/ActorManagerParent.sys.mjs": package["actor_sha256"]}.items():
            if hashlib.sha256(z.read(name)).hexdigest() != want:
                raise ValueError("installed browser module digest mismatch")
    sys.stdout.buffer.write(raw)


SELECTORS = {
    "jscall": ("scriptPath", "functionName", "jsStartLine", "jsStartColumn"),
    "wasm": ("wasmSelector",),
    "http": ("httpPath", "redirectPath"),
    "websocket": ("websocketPath",),
}


def init(args):
    opts = {k: getattr(args, k) for fields in SELECTORS.values() for k in fields if getattr(args, k) is not None}
    if opts.keys() - set(SELECTORS[args.mode]):
        raise ValueError("selector options must match --mode")
    if args.mode == "wasm":
        if "wasmSelector" not in opts:
            raise ValueError("Wasm init requires --wasm-selector add or trap")
        opts = wasm_fields(opts["wasmSelector"])
    config = initialize(args.dir, args.url, args.mode, args.enable, **opts)
    print(json.dumps({"directory": args.dir, "url": target_url(config), "mode": config["mode"],
                      "enabled": config["enabled"], "runId": config["runId"]}, sort_keys=True))
    return 0


def main():
    p = argparse.ArgumentParser(prog="ruyitrace-native", allow_abbrev=False)
    commands = p.add_subparsers(dest="command", required=True)
    setup = commands.add_parser("init", help="create a fresh owner-only run and empty profile", allow_abbrev=False)
    setup.add_argument("--dir", required=True)
    setup.add_argument("--url", required=True, help="literal http://127.0.0.1:PORT plus exact document path")
    setup.add_argument("--mode", choices=MODES, required=True)
    setup.add_argument("--enable", action="store_true", help="explicitly arm telemetry for this run")
    setup.add_argument("--script-path", dest="scriptPath")
    setup.add_argument("--function-name", dest="functionName")
    setup.add_argument("--js-line", dest="jsStartLine", type=int)
    setup.add_argument("--js-column", dest="jsStartColumn", type=int)
    setup.add_argument("--wasm-selector", dest="wasmSelector", choices=WASM)
    setup.add_argument("--http-path", dest="httpPath")
    setup.add_argument("--redirect-path", dest="redirectPath")
    setup.add_argument("--websocket-path", dest="websocketPath")
    run = commands.add_parser("run", help="start the installed Firefox with the saved scope", allow_abbrev=False)
    run.add_argument("--dir", required=True)
    run.add_argument("--url", help="optional assertion; must match the saved URL exactly")
    commands.add_parser("verify", help="hash the installed Firefox and archive modules", allow_abbrev=False)
    if len(sys.argv) == 1:
        p.print_help()
        return 0
    a = p.parse_args()
    try:
        if a.command == "verify":
            verify()
            return 0
        if os.geteuid() == 0:
            raise ValueError("run with the image's unprivileged browser user")
        os.umask(0o077)
        if a.command == "init":
            return init(a)
        c = load_config(a.dir, a.url)
        root = private_dir(a.dir)
        # Only pass data already checked against real uid, inode type, permissions, and scope.
        # Do not forward profile overrides, injection, proxies, or a network/debugger control surface.
        env = {"PATH": "/usr/local/bin:/usr/bin:/bin", "LANG": "C.UTF-8", "TZ": "UTC"}
        for key, leaf in (("HOME", "home"), ("XDG_RUNTIME_DIR", "xdg")):
            directory = root / leaf
            directory.mkdir(mode=0o700)
            env[key] = str(private_dir(directory))
        env["MOZ_RUYITRACE_NATIVE_DIR"] = str(root)
        env["MOZ_RUYITRACE_NATIVE_CONFIG"] = json.dumps(c, separators=(",", ":"))
        firefox = "/browser/firefox"
        os.execve(firefox, [firefox, "-headless", "-no-remote", "-profile", c["profile"], target_url(c)], env)
    except (OSError, ValueError) as e:
        print(f"ruyitrace-native: {e}", file=sys.stderr)
        return 3


if __name__ == "__main__":
    sys.exit(main())
