"""Linux launcher's operator-only configuration checks and fresh run setup."""
import json
import os
from pathlib import Path
import re
import secrets
import stat

MODES = ("jscall", "wasm", "http", "websocket")
DEFAULT_DOCUMENT = "/harness"
FIXED = frozenset(("schema", "origin", "runId", "mode", "enabled", "profile"))
OPTIONAL = {
    "jscall": frozenset(("scriptPath", "functionName", "jsStartLine", "jsStartColumn")),
    "wasm": frozenset(("scriptPath", "functionName", "wasmFunctionIndex", "wasmModuleHash", "wasmEntryOffset", "wasmCompileLine")),
    "http": frozenset(("httpPath", "redirectPath")),
    "websocket": frozenset(("websocketPath",)),
}
WASM = {
    "add": ("f2f415504deccd0e", 35),
    "trap": ("14de952378bf4340", 33),
}
ORIGIN = r"http://127\.0\.0\.1:([1-9][0-9]{0,4})"
PATH = re.compile(r"/[A-Za-z0-9._-]+(?:/[A-Za-z0-9._-]+)*", re.ASCII)
SCRIPT = re.compile(r"/(?:[A-Za-z0-9_-][A-Za-z0-9_.-]*/)*[A-Za-z0-9_-][A-Za-z0-9_.-]*\.m?js", re.ASCII)
FUNCTION = re.compile(r"[A-Za-z_$][A-Za-z0-9_$]{0,63}", re.ASCII)


def natural(value, maximum):
    return type(value) is int and 0 <= value <= maximum


def private_dir(p):
    p = Path(p)
    if not p.is_absolute() or p.resolve(strict=True) != p:
        raise ValueError("absolute canonical directory required")
    s = p.lstat()
    if not stat.S_ISDIR(s.st_mode) or stat.S_IMODE(s.st_mode) != 0o700 or s.st_uid != os.geteuid():
        raise ValueError("a directory owned by the browser user with mode 0700 is required")
    return p


def unique(items):
    record = {}
    for key, value in items:
        if key in record:
            raise ValueError("duplicate configuration key")
        record[key] = value
    return record


def bounded_path(value):
    return (type(value) is str and len(value) <= 96 and PATH.fullmatch(value)
            and not any(part in (".", "..") for part in value.split("/")))


def split_url(url):
    m = re.fullmatch(ORIGIN + r"(/[^\r\n]*)", url, re.ASCII) if type(url) is str else None
    if not m or not 1024 <= int(m[1]) <= 65535 or not bounded_path(m[2]):
        raise ValueError("URL must select one exact path on a literal http://127.0.0.1:PORT origin")
    return url[:-len(m[2])], m[2]


def target_url(config):
    return config["origin"] + config.get("documentPath", DEFAULT_DOCUMENT)


def wasm_fields(which):
    digest, offset = WASM[which]
    return dict(scriptPath="/target.js", functionName=which, wasmFunctionIndex=0,
                wasmModuleHash=digest, wasmEntryOffset=offset, wasmCompileLine=31)


def validate_config(c, url=None):
    if type(c) is not dict or not FIXED <= c.keys() or type(c["mode"]) is not str or c["mode"] not in OPTIONAL:
        raise ValueError("unrecognized native configuration")
    mode = c["mode"]
    if c.keys() - (FIXED | {"documentPath"} | OPTIONAL[mode]) or type(c["enabled"]) is not bool or type(c["schema"]) is not int or c["schema"] != 1:
        raise ValueError("unrecognized native configuration fields")
    origin = c["origin"]
    path = c.get("documentPath", DEFAULT_DOCUMENT)
    if type(origin) is not str or not bounded_path(path) or split_url(origin + path) != (origin, path):
        raise ValueError("invalid configured native origin/document path")
    if url is not None and split_url(url) != (origin, path):
        raise ValueError("URL does not match the configured literal origin and document path")
    if type(c["runId"]) is not str or not re.fullmatch(r"[0-9a-f]{32}", c["runId"]):
        raise ValueError("runId must consist of 32 lowercase hex digits")
    if mode == "jscall":
        script = c.get("scriptPath")
        name = c.get("functionName")
        if not bounded_path(script) or not SCRIPT.fullmatch(script) or type(name) is not str or not FUNCTION.fullmatch(name):
            raise ValueError("invalid approved JavaScript path or function name")
        if any(not natural(c.get(k), 65535) or not c[k] for k in ("jsStartLine", "jsStartColumn")):
            raise ValueError("JS script coordinates must be within 1..65535")
    if mode == "wasm":
        name = c.get("functionName")
        if type(name) is not str or name not in WASM or any(type(c.get(k)) is not type(v) or c[k] != v for k, v in wasm_fields(name).items()):
            raise ValueError("invalid immutable Wasm selector")
    if mode == "http":
        if not bounded_path(c.get("httpPath")):
            raise ValueError("invalid HTTP route")
        if "redirectPath" in c and (not bounded_path(c["redirectPath"]) or c["redirectPath"] == c["httpPath"]):
            raise ValueError("HTTP redirect route must be distinct from --http-path")
    if mode == "websocket" and not bounded_path(c.get("websocketPath")):
        raise ValueError("invalid WebSocket route")
    if type(c["profile"]) is not str or len(c["profile"]) > 512:
        raise ValueError("invalid profile path")
    return c


def initialize(directory, url, mode, enabled, **selectors):
    d = Path(directory)
    if str(d) != directory or not d.is_absolute() or d.parent.resolve(strict=True) != d.parent or d.name in ("", ".", ".."):
        raise ValueError("init requires a fresh canonical absolute run path beneath an existing directory")
    origin, path = split_url(url)
    profile = d / "profile"
    c = validate_config(dict(schema=1, origin=origin, documentPath=path, runId=secrets.token_hex(16),
                             profile=str(profile), mode=mode, enabled=enabled, **selectors), url)
    d.mkdir(mode=0o700)
    private_dir(d)
    profile.mkdir(mode=0o700)
    p = d / ".native-config.pending"
    fd = os.open(p, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, "wb") as f:
        f.write((json.dumps(c, sort_keys=True, separators=(",", ":"), ensure_ascii=True) + "\n").encode("ascii"))
        f.flush()
        os.fsync(f.fileno())
    p.rename(d / "native-config.json")
    return c


def load_config(directory, url=None):
    directory = private_dir(directory)
    fd = os.open(directory / "native-config.json", os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, "rb") as f:
        s = os.fstat(f.fileno())
        if not stat.S_ISREG(s.st_mode) or stat.S_IMODE(s.st_mode) != 0o600 or s.st_uid != os.geteuid() or s.st_nlink != 1:
            raise ValueError("native-config.json must be a private, single-linked operator file (0600)")
        raw = f.read(4097)
    if len(raw) > 4096:
        raise ValueError("native configuration exceeds 4096 bytes")
    c = validate_config(json.loads(raw.decode("utf-8"), object_pairs_hook=unique), url)
    profile = private_dir(c["profile"])
    if profile == directory or profile in directory.parents or any(profile.iterdir()):
        raise ValueError("a separate, fresh profile directory is required")
    # The owner is the controller. Reject leftovers before exec; Gecko also claims its own exclusive writer.
    if any(p.name.startswith("native-") and p.name != "native-config.json" for p in directory.iterdir()):
        raise ValueError("fresh native run directory required")
    return c
