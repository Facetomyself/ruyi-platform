/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

const DEFAULT_DOCUMENT = "/harness";
const DEFAULT_HTTP = "/qa-http";
const DEFAULT_WEBSOCKET = "/qa-ws";
const START = "http-on-modify-request";
const NETWORK = "http-on-examine-response";
const CACHE = "http-on-examine-cached-response";
const TOPICS = [START, NETWORK, CACHE];
const REDIRECT_CATEGORY = "net-channel-event-sinks";
const CONTRACT = "@ruyi.invalid/qualification/net-redirect;1";
const CID = "{cfb45a5a-67c8-458c-a147-d6ec648b54b7}";
const MAX_CHANNELS = 32;
const MAX_CONNECTIONS = 8;
const MAX_FRAMES = 128;
const MAX_LENGTH = 65536;
const MAX_STATS = 0xffff;
const CLEAN = Object.freeze({ limit: 0, failures: 0 });
const WS_CONTRACT = "@mozilla.org/websocketevent/service;1";
const redirectHandlers = new Set();
let redirectFactory;

function isId(value) {
  return Number.isSafeInteger(value) && value > 0;
}

function portOf(origin) {
  const match = /^http:\/\/127\.0\.0\.1:([1-9][0-9]{0,4})$/u.exec(origin);
  const port = match?.[0] === origin ? Number(match[1]) : 0;
  return port > 1023 && port <= 65535 ? port : 0;
}

function isExactPath(value) {
  // Same grammar and size bound as WebSocketEventService::RuyiExactPath.
  return typeof value === "string" && value.length >= 2 && value.length <= 96 &&
    value[0] === "/" && value.slice(1).split("/").every(segment =>
      segment && segment !== "." && segment !== ".." && !/[^A-Za-z0-9._-]/u.test(segment));
}

function selectPaths(cfg) {
  const { documentPath = DEFAULT_DOCUMENT } = cfg;
  const exact = path => {
    if (!isExactPath(path)) {
      throw new Error("native network measurement requires an exact canonical path");
    }
    return path;
  };
  const scoped = { mode: cfg.mode, origin: cfg.origin, documentPath: exact(documentPath) };
  if (cfg.mode === "http") {
    const { httpPath = DEFAULT_HTTP } = cfg;
    scoped.httpPath = exact(httpPath);
    scoped.redirectPath = cfg.redirectPath !== undefined ? exact(cfg.redirectPath) :
      httpPath === "/qa-redirect" ? "/qa-final" : null;
    if (scoped.redirectPath === scoped.httpPath) {
      throw new Error("native HTTP redirect requires distinct source and target paths");
    }
  } else {
    const { websocketPath = DEFAULT_WEBSOCKET } = cfg;
    scoped.websocketPath = exact(websocketPath);
  }
  return Object.freeze(scoped);
}

function loopbackPath(uri, scheme, port) {
  return uri && uri.scheme === scheme && uri.asciiHost === "127.0.0.1" &&
    uri.port === port && !uri.hasQuery && !uri.hasRef && !uri.hasUserPass ? uri.filePath : null;
}

function currentScope(actor, wgp, principal, cfg, port) {
  return actor.manager === wgp && wgp.isCurrentGlobal && !wgp.isClosed &&
    wgp.browsingContext?.parent === null &&
    wgp.browsingContext.currentWindowGlobal === wgp &&
    principal.isContentPrincipal && principal.originNoSuffix === cfg.origin &&
    principal.equals(wgp.documentPrincipal) &&
    loopbackPath(wgp.documentURI, "http", port) === cfg.documentPath;
}

function channelScope(subject, actor, wgp, principal, cfg, port, routes, kind, onCaller) {
  if (!currentScope(actor, wgp, principal, cfg, port)) {
    return null;
  }
  const channel = subject.QueryInterface(Ci.nsIHttpChannel);
  const info = channel.loadInfo;
  // Reject every other document or worker before touching a request URI.
  if (!info || info.innerWindowID !== wgp.innerWindowId ||
      info.browsingContextID !== wgp.browsingContext.id ||
      !principal.equals(info.loadingPrincipal) ||
      !principal.equals(info.triggeringPrincipal)) {
    return null;
  }
  // The caller is exact; an API failure evaluating its route or channel data
  // invalidates the completeness claim, even when the route is unknown.
  onCaller();
  if (kind === "ws") {
    if (info.externalContentPolicyType !== Ci.nsIContentPolicy.TYPE_WEBSOCKET) {
      return null;
    }
  } else if (info.externalContentPolicyType !== Ci.nsIContentPolicy.TYPE_FETCH &&
             info.externalContentPolicyType !== Ci.nsIContentPolicy.TYPE_XMLHTTPREQUEST) {
    return null;
  }
  const route = loopbackPath(channel.URI, "http", port);
  if (!routes.has(route) || channel.requestMethod !== "GET") {
    return null;
  }
  const id = channel.channelId;
  if (!isId(id)) {
    throw new Error("invalid scoped channel ID");
  }
  return { channel, info, route, id };
}

function isDirectChannel(channel) {
  const proxy = channel.QueryInterface(Ci.nsIProxiedChannel).proxyInfo;
  return !proxy || proxy.type === "direct";
}

function addRedirectHandler(handler) {
  if (redirectHandlers.size === 0) {
    const id = Components.ID(CID);
    const registrar = Components.manager.QueryInterface(Ci.nsIComponentRegistrar);
    const sink = {
      QueryInterface: ChromeUtils.generateQI(["nsIChannelEventSink"]),
      asyncOnChannelRedirect(oldChannel, newChannel, flags, callback) {
        try {
          for (const observer of redirectHandlers) {
            try {
              observer(oldChannel, newChannel, flags);
            } catch {
              // A tracing failure never influences redirect verification.
            }
          }
        } finally {
          callback.onRedirectVerifyCallback(Cr.NS_OK);
        }
      },
    };
    const factory = {
      QueryInterface: ChromeUtils.generateQI(["nsIFactory"]),
      createInstance(iid) { return sink.QueryInterface(iid); },
    };
    registrar.registerFactory(id, "Ruyi qualification redirect observer", CONTRACT, factory);
    try {
      Services.catMan.addCategoryEntry(REDIRECT_CATEGORY, CONTRACT, CONTRACT, false, true);
    } catch (error) {
      registrar.unregisterFactory(id, factory);
      throw error;
    }
    redirectFactory = { registrar, factory, id };
  }
  redirectHandlers.add(handler);
  return () => {
    redirectHandlers.delete(handler);
    if (redirectHandlers.size === 0 && redirectFactory) {
      const { registrar, factory, id } = redirectFactory;
      redirectFactory = null;
      try {
        Services.catMan.deleteCategoryEntry(REDIRECT_CATEGORY, CONTRACT, false);
      } finally {
        registrar.unregisterFactory(id, factory);
      }
    }
  };
}

function attachHTTP(actor, wgp, principal, cfg, port, emit) {
  let live = true;
  let nextChain = 1;
  let limit = 0;
  let failures = 0;
  const drop = () => { limit = Math.min(MAX_STATS, limit + 1); };
  const fail = () => { failures = Math.min(MAX_STATS, failures + 1); };
  const records = new Map();
  const topics = [];
  const routes = new Set([cfg.httpPath]);
  if (cfg.redirectPath) {
    routes.add(cfg.redirectPath);
  }
  const scope = (subject, onCaller) => channelScope(subject, actor, wgp, principal,
    cfg, port, routes, "http", onCaller);

  const onRedirect = (oldChannel, newChannel, flags) => {
    const sink = Ci.nsIChannelEventSink;
    if (!live || !(flags & (sink.REDIRECT_TEMPORARY | sink.REDIRECT_PERMANENT)) ||
        flags & (sink.REDIRECT_INTERNAL | sink.REDIRECT_STS_UPGRADE |
                 sink.REDIRECT_TRANSPARENT)) {
      return;
    }
    let exactCaller = false;
    const onCaller = () => { exactCaller = true; };
    try {
      const old = scope(oldChannel, onCaller);
      if (old?.route !== cfg.httpPath) {
        return;
      }
      const previous = records.get(old.id);
      if (!previous || previous.status < 300 || previous.status > 399 ||
          previous.transport !== "network" || previous.hop !== 0) {
        return;
      }
      const replacement = scope(newChannel, onCaller);
      if (replacement?.route !== cfg.redirectPath) {
        return;
      }
      if (replacement.info.redirectChain.length !== 1 ||
          !principal.equals(replacement.info.redirectChain[0].principal) || records.has(replacement.id)) {
        fail();
        return;
      }
      if (records.size >= MAX_CHANNELS) {
        drop();
        return;
      }
      records.set(replacement.id, { chain: previous.chain, route: replacement.route,
        hop: 1, started: false });
    } catch {
      if (exactCaller) {
        fail();
      }
    }
  };

  const observer = {
    observe(subject, topic) {
      if (!live) {
        return;
      }
      let exactCaller = false;
      try {
        const scoped = scope(subject, () => { exactCaller = true; });
        if (!scoped) {
          return;
        }
        const { id, route, channel, info } = scoped;
        let record = records.get(id);
        if (topic === START) {
          if (!record) {
            if (route !== cfg.httpPath || info.redirectChainIncludingInternalRedirects.length !== 0) {
              return;
            }
            if (records.size >= MAX_CHANNELS) {
              drop();
              return;
            }
            record = { chain: nextChain++, route, hop: 0 };
            records.set(id, record);
          }
          if (record.route === route) {
            // Do not admit a prewarm channel that started before attach.
            record.started = true;
          } else {
            fail();
          }
          return;
        }
        if (record?.route !== route || !record.started || record.status !== undefined) {
          return;
        }
        if (record.hop === 1 &&
            (loopbackPath(channel.originalURI, "http", port) !== cfg.httpPath ||
             info.redirectChain.length !== 1 || info.redirectChainIncludingInternalRedirects.length !== 1)) {
          fail();
          return;
        }
        if (!isDirectChannel(channel)) {
          return;
        }
        const status = channel.responseStatus;
        if (!Number.isInteger(status) || status < 100 || status > 599) {
          fail();
          return;
        }
        record.status = status;
        record.transport = topic === CACHE ? "cache" : "network";
        emit({ family: "http", kind: "transaction", chain: record.chain,
          transport: record.transport, method: "GET", status });
      } catch {
        if (exactCaller) {
          fail();
        }
      }
    },
  };
  const removeRedirect = cfg.redirectPath ? addRedirectHandler(onRedirect) : null;
  const cleanup = () => {
    if (live) {
      live = false;
      for (const topic of topics) {
        try {
          Services.obs.removeObserver(observer, topic);
        } catch {
          fail();
        }
      }
      records.clear();
      try {
        removeRedirect?.();
      } catch {
        fail();
      }
    }
    return { limit, failures };
  };
  try {
    for (const topic of TOPICS) {
      Services.obs.addObserver(observer, topic);
      topics.push(topic);
    }
  } catch (error) {
    cleanup();
    throw error;
  }
  return cleanup;
}

function unsupportedWebSocket() {
  const error = new Error("ruyi_websocket_native_metadata_unavailable");
  error.code = "NS_RUYI_UNSUPPORTED";
  return error;
}

function attachWS(actor, wgp, principal, cfg, port, emit) {
  const service = Cc[WS_CONTRACT].getService(Ci.nsIWebSocketEventService);
  if (!Ci.nsIRuyiWebSocketFrameListener ||
      typeof service.addRuyiMetadataListener !== "function" ||
      typeof service.stopRuyiMetadataListener !== "function") {
    throw unsupportedWebSocket();
  }
  let live = true;
  let frameCount = 0;
  let limit = 0;
  let failures = 0;
  const drop = () => { limit = Math.min(MAX_STATS, limit + 1); };
  const fail = () => { failures = Math.min(MAX_STATS, failures + 1); };
  const connections = new Map();
  const routes = new Set([cfg.websocketPath]);
  const scope = (subject, onCaller) => channelScope(subject, actor, wgp, principal,
    cfg, port, routes, "ws", onCaller);
  const listener = {
    QueryInterface: ChromeUtils.generateQI(["nsIRuyiWebSocketFrameListener"]),
    channelAllowed(subject) {
      let exactCaller = false;
      try {
        const scoped = live && scope(subject, () => { exactCaller = true; });
        return Boolean(scoped && scoped.info.redirectChainIncludingInternalRedirects.length === 0);
      } catch {
        if (exactCaller) {
          fail();
        }
        return false;
      }
    },
    onFrame(subject, serial, outgoing, opcode, fin, length) {
      if (!live) {
        return;
      }
      let exactCaller = false;
      try {
        const scoped = scope(subject, () => { exactCaller = true; });
        if (!scoped || scoped.info.redirectChainIncludingInternalRedirects.length !== 0 ||
            !isDirectChannel(scoped.channel)) {
          return;
        }
        if (frameCount >= MAX_FRAMES || (Number.isInteger(length) && length > MAX_LENGTH)) {
          drop();
          return;
        }
        if (!isId(serial) || serial > 0xffffffff || typeof outgoing !== "boolean" ||
            typeof fin !== "boolean" || ![0, 1, 2, 8, 9, 10].includes(opcode) ||
            !Number.isInteger(length) || length < 0 || (opcode >= 8 && (!fin || length > 125))) {
          fail();
          return;
        }
        let connection = connections.get(scoped.id);
        if (!connection) {
          if (connections.size >= MAX_CONNECTIONS) {
            drop();
            return;
          }
          connection = { id: connections.size + 1, serial };
          connections.set(scoped.id, connection);
        }
        if (connection.serial !== serial) {
          fail();
          return;
        }
        ++frameCount;
        emit({ family: "websocket", kind: "frame", connection: connection.id,
          direction: outgoing ? "tx" : "rx", opcode, fin, length });
      } catch {
        if (exactCaller) {
          fail();
        }
      }
    },
  };
  try {
    service.addRuyiMetadataListener(wgp.innerWindowId, port, cfg.websocketPath, listener);
  } catch (error) {
    if (error.result === Cr.NS_ERROR_NOT_IMPLEMENTED) {
      throw unsupportedWebSocket();
    }
    throw error;
  }
  return () => {
    if (live) {
      live = false;
      connections.clear();
      const nativeLimit = {};
      const nativeFailures = {};
      const good = value => Number.isInteger(value) && value >= 0 && value <= MAX_STATS;
      try {
        service.stopRuyiMetadataListener(wgp.innerWindowId, listener, nativeLimit, nativeFailures);
        if (good(nativeLimit.value) && good(nativeFailures.value)) {
          limit = Math.min(MAX_STATS, limit + nativeLimit.value);
          failures = Math.min(MAX_STATS, failures + nativeFailures.value);
        } else {
          fail();
        }
      } catch {
        fail();
      }
    }
    return { limit, failures };
  };
}

// Called by the common parent actor strictly inside its measurement interval.
// No legacy WebSocket listener fallback: it copies data and coalesces fragments.
export function attachNetwork(parentActor, cfg, emit) {
  if (cfg?.schema !== 1 || cfg.enabled !== true || !["http", "websocket"].includes(cfg.mode)) {
    return () => CLEAN;
  }
  const scoped = selectPaths(cfg);
  const port = typeof scoped.origin === "string" ? portOf(scoped.origin) : 0;
  const wgp = parentActor.manager;
  const principal = wgp?.documentPrincipal;
  if (!port || !isId(wgp?.innerWindowId) || !isId(wgp?.browsingContext?.id) ||
      !principal || typeof emit !== "function" || !currentScope(parentActor, wgp, principal, scoped, port)) {
    return () => ({ limit: 0, failures: 1 });
  }
  return scoped.mode === "http"
    ? attachHTTP(parentActor, wgp, principal, scoped, port, emit)
    : attachWS(parentActor, wgp, principal, scoped, port, emit);
}
